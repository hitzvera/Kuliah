package com.pam.tugas2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

//        TextView paragraph = (TextView) findViewById(R.id.article);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        paragraph.setText("test 1 2 3");


    }
}